Kernel.eval(command_options) unless command_options.nil?
