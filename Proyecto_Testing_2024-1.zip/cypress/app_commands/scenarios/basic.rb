# You can setup your Rails state here
# MyModel.create name: 'something'
Post.create(title: 'I am a Postman')
