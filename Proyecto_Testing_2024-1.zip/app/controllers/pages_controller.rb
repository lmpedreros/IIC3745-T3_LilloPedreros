class PagesController < ApplicationController
  # Controlador para las páginas estáticas del sitio.
  def index
    # No se realiza ninguna operación adicional
  end
end
