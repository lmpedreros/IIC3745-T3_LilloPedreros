//= link_tree ../images
//= require activestorage
//= link_directory ../stylesheets .css
//= link_tree ../../../vendor/javascript .js